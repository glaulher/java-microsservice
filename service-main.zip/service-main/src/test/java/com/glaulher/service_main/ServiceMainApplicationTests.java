package com.glaulher.service_main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
